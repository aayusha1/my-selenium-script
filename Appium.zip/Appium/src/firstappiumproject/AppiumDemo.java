package firstappiumproject;

import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import bsh.Capabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class AppiumDemo {

	
	static AppiumDriver <MobileElement>driver;
	public static void setup() throws MalformedURLException
	{
	DesiredCapabilities  capabilities=new DesiredCapabilities();
	capabilities.setCapability("Browser_Name","Chrome");
	capabilities.setCapability("VERSION", "6.0.1");
	capabilities.setCapability("deviceName", "Galaxy S6");
	capabilities.setCapability("platformName", "Android");
		try {
			URL url= new URL("http://0.0.0.0:4723/wd/hub");
			 driver=new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"),capabilities);
	
			
		} catch (MalformedURLException e) {
			
			e.printStackTrace();
		}
driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
public void validateText()
{
	
}
}
