package testchrome;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class VerifyChromeRespond {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.ie.driver", "D:\\selenium\\IEDriverServer.exe");
		
		WebDriver driver=new InternetExplorerDriver ();
		driver.get("https://www.facebook.com/");

	}

}
