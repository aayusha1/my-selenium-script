package lib;

public interface ExcelDataConfig {

	char[] getData(int i, int j, int k);

}
