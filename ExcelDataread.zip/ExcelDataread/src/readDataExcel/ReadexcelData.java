package readDataExcel;
import lib.ExcelDataConfig;

public class ReadexcelData {

	public static void main(String[] args) {
		ExcelDataConfig excel=new ExcelDataConfig("D:\\selenium\\TestData.xlsx");
		System.out.println(excel.getData(0,0,0));

	}

}
