package loopdemo;

public class Forloop {

	public static void main(String[] args) {
		int r=40;
		for(r=0;r<50;r++)
		{
			System.out.println("The value of r is "+r);
		}

	}

}
