package loopdemo;

public class Whileloop {

	public static void main(String[]args) {
		
		
	int count=10;
	while (count <=20)
		{
			System.out.println("The number  is"+count);
		}
		
		
		

	}
}

