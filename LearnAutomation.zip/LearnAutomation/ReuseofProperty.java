package testseleniumproperty;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import configchrome.ConfigurationRead;

@Test
public class ReuseofProperty {
	public void testResult() throws Exception
	{
		ConfigurationRead config=new ConfigurationRead();
		
		System.setProperty("webdriver.chrome.driver",config.getChrome());
		WebDriver driver=new ChromeDriver();
		driver.get(config.getApplicationURL());
		driver.quit();
	}

}
