package ReadAlldatafromExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class testreaddata {
	XSSFWorkbook wb;
	XSSFSheet sheet1;

	public static void main(String[] args) throws Exception  {
		
File src=new File ("D:\\selenium\\TestData.xlsx");
FileInputStream fis=new FileInputStream(src);

 wb=new XSSFWorkbook(fis);
 sheet1=wb.getSheetAt(0);


	}

}
