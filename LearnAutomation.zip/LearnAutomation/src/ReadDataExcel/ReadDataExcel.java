package ReadDataExcel;

import libreuse.ExcelDataConfig;

public class ReadDataExcel {
	public static void main (String []args){
		ExcelDataConfig excel=new ExcelDataConfig("D:\\ExcelData\\TestData1.xlsx");
		System.out.println(excel.getData(0,1,0));
	}

}
