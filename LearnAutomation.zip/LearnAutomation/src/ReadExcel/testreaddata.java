package ReadExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class testreaddata {
	
public static void main (String[] args) throws IOException
{
	File src=new File ("D:\\selenium\\TestData.xlsx");
	FileInputStream fis=new FileInputStream(src);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sheet1=wb.getSheetAt(0);
	int rowcount= sheet1.getLastRowNum();
	System.out.println("Total row is"+rowcount);
	
for(int i=0;i<rowcount;i++)
{
	String datatest=sheet1.getRow(i).getCell(0).getStringCellValue();
	System.out.println("The data from excel is "+datatest);
	


}

wb.close();

}

}

