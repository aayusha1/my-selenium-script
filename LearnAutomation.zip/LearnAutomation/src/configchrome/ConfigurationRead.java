package configchrome;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationRead {
	Properties pro;
	
	public  ConfigurationRead()
	{
		try {
			File src=new File("./ConfigurationDemo/config.property");
			FileInputStream fis=new FileInputStream(src);
		    pro=new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println("Exception is =="+e.getMessage());
			
		} 
		
}

public String getChrome()
{
	String path=pro.getProperty("chromeDriver");
	return path;
}
public String getApplicationURL()
{
	return pro.getProperty("Url");
}
}