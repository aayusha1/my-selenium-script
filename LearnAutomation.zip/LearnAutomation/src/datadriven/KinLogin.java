package datadriven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class KinLogin {
	WebDriver driver;

     @Test(dataProvider="KinData")
	public void loginToDashboard(String username,String password) throws InterruptedException
      {
    	 System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
 		 driver= new ChromeDriver();
 		driver.get("http://www.kilmainham-inchicore.ie/admin/");
 		//driver.manage().window().maximize();
 		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
 		
 		driver.findElement(By.name("username")).sendKeys(username);
 		driver.findElement(By.name("password")).sendKeys(password);
 		driver.findElement(By.name("submit")).click();
 		Thread.sleep(5000);
 		System.out.println(driver.getTitle());
 		Assert.assertTrue(driver.getTitle().contains("Dashboard"),"user is not able to login-invalid credentials ");
 		System.out.println("title is verified-user is able to login");

      }
     
       @AfterMethod
 		public void teardown()
 		{
    	   driver.quit();
 		}
 		@DataProvider(name="KinData")
 		
 		public Object[][] passData()
 		{
 			Object[][]data=new Object[3][2];
 					data[0][0]="admin";
 					data[0][1]="admin123";
 					
 					data[1][0]="admin";
 					data[1][1]="Kin@admin12";
 					
 					data[2][0]="admin1";
 					data[2][1]="admin123";
 					return data;
 		}
 		
 		
 
 				
	}


