package datadriven;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import libreuse.ExcelDataConfig;

public class KinLoginwithExceldata {
	WebDriver driver;

     @Test(dataProvider="KinData")
	public void loginToDashboard(String sheetnumber,String username,String password) throws InterruptedException
      {
    	 System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
 		 driver= new ChromeDriver();
 		driver.get("http://www.kilmainham-inchicore.ie/admin/");
 		//driver.manage().window().maximize();
 		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
 		
 		driver.findElement(By.name("username")).sendKeys(username);
 		driver.findElement(By.name("password")).sendKeys(password);
 		driver.findElement(By.name("submit")).click();
 		Thread.sleep(5000);
 		System.out.println(driver.getTitle());
 		Assert.assertTrue(driver.getTitle().contains("Dashboard"),"user is not able to login-invalid credentials ");
 		System.out.println("title is verified-user is able to login");

      }
     
       @AfterMethod
 		public void teardown()
 		{
    	   driver.quit();
 		}
 		@DataProvider(name="KinData")
 		
 		public Object[][] passData()
 	
 		{
 			ExcelDataConfig config=new ExcelDataConfig("C:\\Users\\User\\Desktop\\LearnAutomation\\TestData\\InputData.xlsx");
 			int rows=config.getRowCount(0);
 			
 	         Object[][]data=new Object[rows][2];
 			for(int i=0;i<rows;i++)
 			{
 				
 					data[i][0]=config.getData(0,i,0);
 					data[i][1]=config.getData(0,i,1);
 			}	
 					return data;
 		}
 		
 		
 
 				
	}


