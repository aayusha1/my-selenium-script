package libreuse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelDataConfig {
	XSSFWorkbook wb;
	XSSFSheet sheet1;
@Test
	public ExcelDataConfig(String excelPath)
	{
		try {
			File src=new File (excelPath);
			FileInputStream fis=new FileInputStream(src);

			 wb=new XSSFWorkbook(fis);
			 
			
		}
		
		 catch (Exception e) {
			System.out.println(e.getMessage());
			
			
		}
	
}
public String getData(int sheetNumber,int row,int column){
	
	  sheet1=wb.getSheetAt(sheetNumber);
	  
	String data=sheet1.getRow(row).getCell(column).getStringCellValue();
	return data;
	

}
public int getRowCount(int i) {
	// TODO Auto-generated method stub
	return 0;
}
}
