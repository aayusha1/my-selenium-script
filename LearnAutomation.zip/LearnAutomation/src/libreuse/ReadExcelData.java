package libreuse;

import org.testng.annotations.Test;

public class ReadExcelData {
@Test
	public static void main(String[] args) {
		ExcelDataConfig excel=new ExcelDataConfig("D:\\selenium\\TestData.xlsx");
		System.out.println (excel.getData(0, 0, 2));

	}

}
