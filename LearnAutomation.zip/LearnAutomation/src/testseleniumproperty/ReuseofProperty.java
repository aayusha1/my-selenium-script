package testseleniumproperty;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import configchrome.ConfigurationRead;



public class ReuseofProperty {
	ConfigurationRead config;

	@BeforeTest
	public void setUp()
	{
		config=new ConfigurationRead();
		System.setProperty("webdriver.chrome.driver",config.getChrome());
		System.out.println("The Setup is ready");
		
	}
	@Test	
	public void testResult() throws Exception
	{
		System.out.println("The  test started");
		WebDriver driver=new ChromeDriver();
		driver.get(config.getApplicationURL());
		
		driver.quit();
		System.out.println("The test is ended");
	}

}
