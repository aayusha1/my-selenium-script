package Firefoxdemo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Firefoxdriver {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","D:\\selenium\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath(".//*[@id='u_0_9']")).sendKeys("aayusha");
		driver.findElement(By.xpath(".//*[@id='u_0_b']")).sendKeys("gaire");
		driver.findElement(By.xpath(".//*[@id='u_0_e']")).sendKeys("9847150598");
		driver.findElement(By.xpath(".//*[@id='u_0_l']")).sendKeys("august1990");
		driver.findElement(By.xpath("//*[@id='u_0_6']")).click();
		Select sel1=new Select(driver.findElement(By.xpath("//*[@id='month']")));
		sel1.selectByVisibleText("Aug");
		Select sel2=new Select(driver.findElement(By.xpath(".//*[@id='day']")));
		sel2.selectByValue("6");
		Select sel3=new Select(driver.findElement(By.xpath(".//*[@id='year']")));
		sel3.selectByValue("1990");
		driver.findElement(By.xpath("//*[@id='u_0_r']")).click();
		driver.navigate().back();
		//driver.quit();
		
				
		
	}

}
