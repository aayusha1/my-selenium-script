package Newpackage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebookregistration {
	

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.chromedriver", "D:\\selenium\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.get("http://www.facebook.com");
System.out.println(driver.getTitle());
	}

}
