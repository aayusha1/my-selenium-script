package captureScreenshot;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.TakeScreenshot;
import.org.testing.annotations.Test;

@ Test
public class Facebookscreenshot {

	public  void captureScreenshot()
	{
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.facebook,com");
		driver.manage().window().maximize();
		driver.findElement(By.xpath(["//*[@id="email"]")).sendKeys("learn automation");
		TakeScreenshot ts=(TakeScreenshot)driver;
		Filesource=ts.getScreenshotAS(OutputType.FILE);
		FileUtils.copyFile(source, newFile("./screenshot/"));
		System.out.println("screenshot taken");
	}

}
