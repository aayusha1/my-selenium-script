package captureScreenshot;

public interface TakeScreenshot {

}
