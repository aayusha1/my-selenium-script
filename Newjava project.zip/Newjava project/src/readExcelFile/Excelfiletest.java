package readExcelFile;

import org.apache.xpath.operations.String;

import com.gargoylesoftware.htmlunit.javascript.host.file.File;

public class Excelfiletest {

	public static void main(String[] args) {
		File src=new File("D:\\selenium");
		FileInputStream fis=new FileInputStream(src);
		XSSFWorkbook wb=new XSSFWorkbook (fis);
		XSSFSheet sheet 1=wb.getSheetAt(0);
	String data0=sheet1.get

	}

}
