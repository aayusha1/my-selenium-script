package screenshot;

public class String {

}
