package explorerRecruiter;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RecruiterTest {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium_package\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://d2airr4tk971v6.cloudfront.net");
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.name("email")).sendKeys("a1a1@hiupapp.com");
		driver.findElement(By.name("password")).sendKeys("password");
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.findElement(By.className("auth0-label-submit")).click();
		//Thread.sleep(5000);
	     System.out.println("The recruiter page is opened sucessfully ");
		driver.findElement(By.id("company-nav-dropdown")).click();//clicks the menu option Companies
		Thread.sleep(2000);
		driver.findElement(By.linkText("Active Companies")).click();//For link to choose from between (a anchor to /a anchor)//Clicks Active companies
		driver.findElement(By.xpath("//div/div/div[1]/section/div/div[1]/div[2]/button")).click();//Clicks add new company
		driver.findElement(By.id("formHorizontalEmail")).sendKeys("Olivemedia");//Input olivemedia to company name form
		Thread.sleep(6000);
		driver.findElement(By.xpath("//html/body/div[3]/div/div[2]/div/div/div[2]/div[2]/div[1]/div/div[1]/form/div[2]/div/button")).click();
		driver.findElement(By.xpath("//html/body/div[3]/div/div[2]/div/div/div[2]/div[2]/div[1]/div/div[1]/form/div[2]/div/button[2]")).click();
		
		driver.findElement(By.xpath("//html/body/div[7]/div/div[2]/div/div/div[2]/div[2]/div[1]/div/div[1]/form/div[2]/div/button[3]")).click();
	}

}
