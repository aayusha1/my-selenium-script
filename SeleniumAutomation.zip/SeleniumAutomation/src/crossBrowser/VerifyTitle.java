package crossBrowser;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class VerifyTitle {
	
	WebDriver driver;
	
    @Test
	@Parameters("browser")
	
	public void verifypageTitle(String browserName) throws InterruptedException{
		
		if(browserName.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver","D:\\selenium\\geckodriver.exe");
			
			 driver = new FirefoxDriver();
			 Thread.sleep(1000);
			 
			 
	   
			
		}
		else if (browserName.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
			driver=new ChromeDriver();
	
			Thread.sleep(1000);
		}
		else if (browserName.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", "D:\\selenium\\IEDriverServer.exe");
			
		driver=new InternetExplorerDriver ();
		Thread.sleep(1000);
		
		}
		driver.get("http://oliveaus.graphenecreative.co.uk/");
		System.out.println(driver.getTitle());
		driver.quit();
		
		
	}

}
