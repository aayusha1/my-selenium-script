package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class ConnectMySql {
@Test
public void testDB() throws ClassNotFoundException, SQLException
{
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Driver is loaded");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selenium","root","");
	System.out.println("Connected to mysql DB");
	Statement stm=con.createStatement();
	ResultSet res= stm.executeQuery("select * from users");
	//System.out.println("Data records is "+res);
	while(res.next())
	{ 
		String firstname=res.getString("firstname");
		//System.out.println(firstname);
		String email=res.getString("email");
		System.out.println(email);
	}
	
	
}



}

