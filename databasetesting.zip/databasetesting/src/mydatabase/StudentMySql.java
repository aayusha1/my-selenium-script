package mydatabase;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class StudentMySql {
	@Test

	public void testDB() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver is loaded");
	
		Connection con=DriverManager.getConnection("https://www.db4free.net/phpMyAdmin/index.php");
		System.out.println("Connected to mysql DB");
		Statement stm=con.createStatement();
		ResultSet res= stm.executeQuery("select * from studentinfo");
		while(res.next())
		{
			String name=res.getString("name");
			System.out.println("Database record is "+name);
		}

}}
