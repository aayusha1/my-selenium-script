package facebooktest;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;

public class MyFacebook {
public static void main(String[] args){
	
	        System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
			WebDriver driver = new WebDriver();
	 
	 
	 driver.get("https://www.facebook.com");
	  driver.quit(); 
	  
	    }

}


