package classdemo;

public class Classbuilt {

	public static void main(String[] args) {
		String name="Practice selenium";
		
       Boolean value= name.startsWith("Practice");
       
      // System.out.println("The result is "+value);
       
       String name2="Selenium is a open source tool";
       
      Boolean value2= name2.endsWith("tool");
      
     //  System.out.println("The result is "+value2);
       //Eg of String starts with and ends with method (above)with boolean value true n false .
      
      
      // Eg of boolean with method equal and equal ignore case .
      String actual="Selenium webdriver testing tool";
      String expected="Selenium webdriver testing tool";
  //  Boolean status=  actual.equals(expected);
   // System.out.println("The result is "+status);
      Boolean status2=actual.equalsIgnoreCase(expected);
      System.out.println("The result is "+status2);
    
       
       

	}

}
