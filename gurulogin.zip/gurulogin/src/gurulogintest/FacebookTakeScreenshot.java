package gurulogintest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import reuseScreenshot.StoreScreenshot;

public class FacebookTakeScreenshot {


@Test

public void CaptureScreenshot() throws Exception
{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver= new ChromeDriver();
	driver.get("http://www.demo.guru99.com/V4/");
	StoreScreenshot.captureScreenshot(driver, "Browser started");
	driver.findElement(By.name("uid")).sendKeys("mngr116");
	StoreScreenshot.captureScreenshot(driver,"username.png" );
	driver.findElement(By.name("password")).sendKeys("UtAjErA");
	StoreScreenshot.captureScreenshot(driver,"password.png" );
	
	TakesScreenshot ts=(TakesScreenshot)driver;
	File source=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(source, new File("./CaptureScreenshot/gurudemo.png"));
	
	driver.close();
} 
}