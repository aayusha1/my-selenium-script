package gurulogintest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GuruLogin {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.demo.guru99.com/V4/");
		
		driver.findElement(By.name("uid")).sendKeys("mngr116217");
		driver.findElement(By.name("password")).sendKeys("UtAjErA");
		driver.findElement(By.name("btnLogin")).click();
		Thread.sleep(5000);
		//System.out.println("The user is login");
		String expectedTitle= "Guru99 Bank Home Page";
		
		String actualTitle=driver.getTitle();
		if (actualTitle.contentEquals(expectedTitle)){
		System.out.println("test passed");
		}
		else
		{
			System.out.println("test failed");
		}
		driver.close();
		
	}

}
