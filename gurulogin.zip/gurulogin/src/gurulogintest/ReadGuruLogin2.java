package gurulogintest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ReadGuruLogin2 {
	WebDriver driver;
@Test(dataProvider="Gurulogin Data")
	public  void LoginGuru(String username,String password) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		 driver= new ChromeDriver();
		driver.get("http://www.demo.guru99.com/V4/");
		
		driver.findElement(By.name("uid")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("btnLogin")).click();
		Thread.sleep(5000);
		//System.out.println("The user is login");
		String expectedTitle= "Guru99 Bank Home Page";
}
 @AfterMethod
	public void teardown()
	{
		driver.quit();
	}

@DataProvider(name="Gurulogin Data")
		public Object[][] passData()
		{
			Object [][]data=new Object [4][2];
			data[0][0]="mngr116217";
			data[0][1]="UtAjErA";
			
			data[1][0]="abcd";
			data[1][1]="mngr116217";
			
			data[2][0]="mtest";
			data[2][1]="mngr116217";
			
			data[3][0]="mngr116";
			data[3][1]="mngr116217";
			return data;
			
			
		}
		
		

		
	}


