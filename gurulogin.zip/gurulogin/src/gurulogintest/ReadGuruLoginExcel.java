package gurulogintest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import guruTestExcel.ExcelReadDemo;

public class ReadGuruLoginExcel {
	WebDriver driver;
@Test(dataProvider="Gurulogin Data")
	public  void LoginGuru(String username,String password) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		 driver= new ChromeDriver();
		driver.get("http://www.demo.guru99.com/V4/");
		
		driver.findElement(By.name("uid")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("btnLogin")).click();
		Thread.sleep(5000);
		//System.out.println("The user is login");
		String expectedTitle= "Guru99 Bank Home Page";
}
 @AfterMethod
	public void teardown()
	{
		driver.quit();
	}

@DataProvider(name="Gurulogin Data")
		public Object[][] passData()
		{ 
		ExcelReadDemo readfile=new ExcelReadDemo("C:\\Users\\User\\Desktop\\excel\\GivenData.xlsx");
			int rows=readfile.getRowCount(0);
			Object[][] data=new Object[rows][2];
			for(int i=0;i<rows;i++)
			{
				data[i][0]=readfile.getData(0, i, 0);
				data[i][1]=readfile.getData(0, i, 1);
			}
			
			return data;
		}
		
		

		
	}


