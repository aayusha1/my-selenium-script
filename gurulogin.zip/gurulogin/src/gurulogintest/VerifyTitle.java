package gurulogintest;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class VerifyTitle {
	@Test
	public void VerifyApplicationTitle()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.demo.guru99.com/V4/");
		String actualTitle=driver.getTitle();
		String expectedTitle="Guru99 Bank Home Page";
		Assert.assertEquals(actualTitle, expectedTitle);
		System.out.println("Test completed");
		driver.close();
	}

}
