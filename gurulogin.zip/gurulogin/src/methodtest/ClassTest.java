package methodtest;

public class ClassTest {

	public static void main(String[] args) {
		MethodClass obj=new MethodClass();
		obj.life();

	}

}
