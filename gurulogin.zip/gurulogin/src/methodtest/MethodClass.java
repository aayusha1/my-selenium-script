package methodtest;

public class MethodClass {
	String name="aayusha";
	String dream="happy";
	
	public static void main(String[] args) {
	MethodClass.life();	

	}
	public static void life()
	{
		System.out.println("Life is beautiful");
	}

}
