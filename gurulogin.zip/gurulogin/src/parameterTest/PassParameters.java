package parameterTest;

public class PassParameters {


int c;
	public static void main(String[] args) {
	PassParameters obj=new PassParameters();
	double sum=obj.add(20.09, 30.1);
	System.out.println("The added value is "+sum);
	int multiply=obj.mult(23, 20);
	System.out.println("The multiplied amount is "+multiply);


	}
public int mult(int a,int b)
{
	c=a*b;
	return c;
}
public double add(double q,double w)
{
	double response=q+w;
	return response;
}
}
