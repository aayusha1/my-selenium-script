package parameterTest;

public class TestParameters {

	public static void main(String []args) {
		TestParameters obj=new TestParameters();
     String fullname=obj.display(aayusha, gaire);
			
		

	
		
	}
public static String display(String name,String lastname)
{
	
	String fullname=name+lastname;
	System.out.println("The fullname is "+fullname);
	return fullname;
}
}
