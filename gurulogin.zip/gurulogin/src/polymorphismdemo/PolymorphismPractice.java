package polymorphismdemo;

public class PolymorphismPractice {

	public static void main(String[] args) {
		PolymorphismPractice obj=new PolymorphismPractice();// this is example of method oveloading as one method is used mutiple times in mutliple ways 
		obj.sum(39, 20.29);
		obj.sum(20, 30);
		obj.sum(30, 12, 34);

     
	}
	public void sum(int a, int b)
	{
		int c=a+b;
		System.out.println("The result is " +c);
	}

	public void sum(int a,int b,int c)
	{
		int d=a+b+c;
		System.out.println("The result is " +d);
	}
	public void sum (String name, String lastname)
	{
		String fullname=name+lastname;
		System.out.println(fullname);
	}
	public void sum (int a,double b)
	{
	double c=a+b;
	System.out.println("The result is " + c);
	
}}
