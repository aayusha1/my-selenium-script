package reuseScreenshot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

public class StoreScreenshot {

	public static void captureScreenshot(WebDriver driver,String capturescreenshotName)
	{
		try {
			TakesScreenshot ts=(TakesScreenshot)driver;
			File source=ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File("./CaptureScreenshot/"+capturescreenshotName+".png"));
			System.out.println("The screen shot is captured");
		} catch (Exception e) {
			System.out.println("The exception message is "+e.getMessage());
			
		}
	}

}
