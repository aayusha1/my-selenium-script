package kinsite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Kintest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://kinstaging.graphenecreative.co.uk");
		//String tagName = "";
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//html/body/header/div/div[1]/div[3]/div/a[1]")).click();
		
		driver.findElement(By.xpath("/html/body/div[5]/div/div/div[2]/form/div[1]/div/input")).sendKeys("aayushagaire1234");
		driver.findElement(By.id("password")).sendKeys("aayushagaire1234");
		driver.findElement(By.xpath("//html/body/div[5]/div/div/div[2]/form/button")).submit();
		

	}

}
