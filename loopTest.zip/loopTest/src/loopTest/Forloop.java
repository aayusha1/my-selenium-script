package loopTest;

public class Forloop {

	public static void main(String[] args) {
		
		System.out.println("loop satarted");
		
		for(int i=0;i<100;i=i+2)
		{
			System.out.println("The value is "  +i );
		}
		
System.out.println("loop ended");
	}

}
