package loopTest;

public class Whileloop {

	public static void main(String[] args) {
		int subject=15;
		
		
		while(subject<20)
			
		System.out.println("The subject is met"+subject);
		subject++;
		
		}
			

	}


