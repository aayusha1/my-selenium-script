package seleniumDemoscreenshot;



import org.testng.annotations.Test;
import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testfacebook {

	@Test
	public static void main(String[] args, File source)throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://www.facebook.com");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("learn automation");
		TakesScreenshot ts= (TakeScreenshot)driver;
	    ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(source, newFile("./screenshot/facebook.png"));
		System.out.println("screenshot taken");
		driver.quit();
		

	}

	private static File newFile(String string) {
		
		return null;
	}

}
