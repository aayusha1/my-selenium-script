
package methodDemo;

public class MethodObject {
	
int a=90,b=100,c;

	public static void main(String[] args) {
	
		MethodObject obj=new MethodObject();
		obj.sum(20, 34);
		System.out.println("The sum is printed");
		

	}
	public  void  sum(int a,int b)
	{
int c=a+b;
		
		System.out.println("the sum is "+c);
	}

}
